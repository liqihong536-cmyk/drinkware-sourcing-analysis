Add dashboard screenshots here, named to match the links in the main README:
- dashboard_overview.png
- dashboard_insulated.png
- dashboard_glass.png
